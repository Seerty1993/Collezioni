package com.emanuele.collezioni.model.enumModel;

public enum CardRarity {
    PROMO,
    RARE,
    HOLO,
    RAREHOLO,
    REVERSEHOLO,
    ULTRARARE,
    SECRETRARE,
    MYTHIC

}
