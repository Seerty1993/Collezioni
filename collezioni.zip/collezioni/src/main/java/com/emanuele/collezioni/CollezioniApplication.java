package com.emanuele.collezioni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollezioniApplication {

    public static void main(String[] args) {
        SpringApplication.run(CollezioniApplication.class, args);
    }

}
