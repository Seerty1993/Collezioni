package com.emanuele.collezioni.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Getter
@Setter
@Table(name = "tipo_beyblade_punte")
public class TipoBeybladePunte {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(unique = true, nullable = false, name = "namePoint")
    private Integer namePoint;
    @Column(unique = true, nullable = false, name = "weight")
    private Integer weight;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "nameBlades")
    @Column(name = "originBeyFrom")
    private List<TipoBeybladeBlades> originBeyFrom;
    @Column(unique = true, nullable = false,name = "owned")
    private boolean owned;
    @OneToOne(mappedBy = "punta")
    private Beyblade beyblade;

}
