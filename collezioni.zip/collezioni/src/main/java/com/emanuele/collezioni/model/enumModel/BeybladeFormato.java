package com.emanuele.collezioni.model.enumModel;

public enum BeybladeFormato {
    TAKARA_TOMY,
    HASBRO
}
