package com.emanuele.collezioni.model.enumModel;

public enum CategoryEnum {
    CARDS,
    BEYBLADE,
    ACTION_FIGURE,
    FUNKO_POP
}
