INSERT INTO collezioni.tipo_beyblade_ratchet (height, bumps, weight)
VALUES(60, 3, 6.30),
(80, 3, 7.10),
(60, 4, 6.40);

INSERT INTO collezioni.tipo_beyblade_punte
(name_point, "owned", weight, originBeyFrom)
VALUES( 0, false, 0);

INSERT INTO collezioni.tipo_beyblade_blades
(name_blades, punte_id, ratchet_id,originBeyFrom)
VALUES( '', 0, 0);


INSERT INTO collezioni.category( name_category)
VALUES( 'Beyblade'),
('Cards');

