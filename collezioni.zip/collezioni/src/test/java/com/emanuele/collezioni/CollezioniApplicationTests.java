package com.emanuele.collezioni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollezioniApplicationTests {

    @Test
    void contextLoads() {
    }

}
